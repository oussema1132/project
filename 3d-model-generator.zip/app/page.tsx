"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Loader2, Sparkles, CuboidIcon as Cube, Image, History, Download } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"

interface GenerationResult {
  id: string
  prompt: string
  expandedPrompt: string
  imageUrl: string
  modelUrl: string
  timestamp: string
  status: "completed" | "processing" | "failed"
}

export default function AI3DGenerator() {
  const [prompt, setPrompt] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentStep, setCurrentStep] = useState("")
  const [results, setResults] = useState<GenerationResult[]>([])
  const [currentResult, setCurrentResult] = useState<GenerationResult | null>(null)

  const handleGenerate = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)
    setCurrentStep("Expanding prompt with AI...")

    try {
      // Step 1: Expand prompt using AI
      const expandResponse = await fetch("/api/expand-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      })

      const { expandedPrompt } = await expandResponse.json()

      setCurrentStep("Generating image from expanded prompt...")

      // Step 2: Generate image (simulated)
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setCurrentStep("Converting image to 3D model...")

      // Step 3: Generate 3D model (simulated)
      await new Promise((resolve) => setTimeout(resolve, 3000))

      const newResult: GenerationResult = {
        id: Date.now().toString(),
        prompt,
        expandedPrompt,
        imageUrl: "/placeholder.svg?height=400&width=400",
        modelUrl: "/assets/3d/duck.glb", // Using the built-in 3D model
        timestamp: new Date().toLocaleString(),
        status: "completed",
      }

      setResults((prev) => [newResult, ...prev])
      setCurrentResult(newResult)
      setCurrentStep("Generation completed!")
    } catch (error) {
      console.error("Generation failed:", error)
      setCurrentStep("Generation failed. Please try again.")
    } finally {
      setIsGenerating(false)
      setTimeout(() => setCurrentStep(""), 3000)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Cube className="h-8 w-8 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              AI Creative 3D Generator
            </h1>
          </div>
          <p className="text-gray-600 text-lg">Transform your creative ideas into stunning 3D models using AI</p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Create Your Vision
                </CardTitle>
                <CardDescription>Describe what you want to create and let AI bring it to life</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Creative Prompt</label>
                  <Input
                    placeholder="A futuristic city skyline at sunset..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    disabled={isGenerating}
                  />
                </div>

                <Button onClick={handleGenerate} disabled={isGenerating || !prompt.trim()} className="w-full" size="lg">
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate 3D Model
                    </>
                  )}
                </Button>

                {currentStep && (
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-700 font-medium">{currentStep}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Generation History */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Recent Generations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  {results.length === 0 ? (
                    <p className="text-gray-500 text-sm text-center py-8">
                      No generations yet. Create your first 3D model!
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {results.map((result) => (
                        <div
                          key={result.id}
                          className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                          onClick={() => setCurrentResult(result)}
                        >
                          <p className="font-medium text-sm truncate">{result.prompt}</p>
                          <div className="flex items-center justify-between mt-1">
                            <Badge variant={result.status === "completed" ? "default" : "secondary"}>
                              {result.status}
                            </Badge>
                            <span className="text-xs text-gray-500">{result.timestamp}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            {currentResult ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Generation Result</span>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="preview" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="preview">3D Preview</TabsTrigger>
                      <TabsTrigger value="image">Generated Image</TabsTrigger>
                      <TabsTrigger value="details">Details</TabsTrigger>
                    </TabsList>

                    <TabsContent value="preview" className="mt-4">
                      <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Cube className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">3D Model Preview</p>
                          <p className="text-sm text-gray-500 mt-1">Interactive 3D viewer would be displayed here</p>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="image" className="mt-4">
                      <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Image className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">Generated Image</p>
                          <p className="text-sm text-gray-500 mt-1">Source image used for 3D generation</p>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="details" className="mt-4">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Original Prompt</h4>
                          <p className="text-sm text-gray-600 p-3 bg-gray-50 rounded-lg">{currentResult.prompt}</p>
                        </div>

                        <Separator />

                        <div>
                          <h4 className="font-medium mb-2">AI Expanded Prompt</h4>
                          <p className="text-sm text-gray-600 p-3 bg-gray-50 rounded-lg">
                            {currentResult.expandedPrompt}
                          </p>
                        </div>

                        <Separator />

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Status:</span>
                            <Badge
                              className="ml-2"
                              variant={currentResult.status === "completed" ? "default" : "secondary"}
                            >
                              {currentResult.status}
                            </Badge>
                          </div>
                          <div>
                            <span className="font-medium">Generated:</span>
                            <span className="ml-2 text-gray-600">{currentResult.timestamp}</span>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-96">
                  <div className="text-center">
                    <Cube className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-600 mb-2">Ready to Create</h3>
                    <p className="text-gray-500">Enter a creative prompt to generate your first 3D model</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
