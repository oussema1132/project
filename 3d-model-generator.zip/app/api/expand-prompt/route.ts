export async function POST(req: Request) {
  try {
    const { prompt } = await req.json()

    if (!prompt) {
      return Response.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Try to use local LM Studio API first
    try {
      const response = await fetch("http://localhost:1234/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "llama3", // Or whatever model name LM Studio shows
          messages: [
            {
              role: "user",
              content: `Expand this into a vivid visual scene for 3D model generation: ${prompt}`,
            },
          ],
          temperature: 0.7,
          max_tokens: 200,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const expandedPrompt = data.choices[0].message.content
        console.log("Successfully expanded prompt using local LLM")
        return Response.json({ expandedPrompt })
      } else {
        throw new Error(`LM Studio API returned ${response.status}`)
      }
    } catch (localError) {
      console.warn("Local LM Studio not available, using fallback:", localError.message)

      // Fallback to a more detailed mock expansion
      const mockExpanded = `A highly detailed and cinematic scene featuring: ${prompt}. 
The composition includes dramatic lighting with warm golden hour tones, 
realistic materials and textures, atmospheric depth with subtle fog or haze, 
and professional 3D rendering quality. The scene is optimized for 3D model generation 
with clear geometric forms, well-defined surfaces, and artistic visual appeal.`

      return Response.json({ expandedPrompt: mockExpanded })
    }
  } catch (error) {
    console.error("Error in expand-prompt route:", error)
    return Response.json({ error: "Failed to expand prompt" }, { status: 500 })
  }
}
